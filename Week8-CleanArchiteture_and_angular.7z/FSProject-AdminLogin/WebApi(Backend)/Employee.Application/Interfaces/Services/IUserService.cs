﻿using Employee.Application.Dtos;

public interface IUserService
{
    Task<IEnumerable<UserDto>> GetAllAsync();
    Task<UserDto?> GetByIdAsync(int id);
    Task SetRoleAsync(int id, string role);
}