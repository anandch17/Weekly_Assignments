﻿namespace Employee.Application.Dtos
{
    public record EmployeeCreateDto(string Name, string? Position, string?Password,decimal Salary);
    public record EmployeeUpdateDto(string Name, string? Position, decimal Salary);

       public record EmployeeDto(int Id, string Name, string? Position, decimal Salary);
}
