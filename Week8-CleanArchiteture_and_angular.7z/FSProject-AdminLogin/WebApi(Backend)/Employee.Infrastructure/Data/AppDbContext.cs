﻿

using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Employee.Domain.Entities;
using EmployeeEntity = Employee.Domain.Entities.Employee;

namespace Employee.Infrastructure.Data
{
    public class AppDbContext: DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasOne(u => u.Employee)
                .WithOne(e => e.User)
                .HasForeignKey<EmployeeEntity>(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        }

        public DbSet<EmployeeEntity> Employees => Set<EmployeeEntity>();

        public DbSet<User> Users => Set<User>();
    }
}
