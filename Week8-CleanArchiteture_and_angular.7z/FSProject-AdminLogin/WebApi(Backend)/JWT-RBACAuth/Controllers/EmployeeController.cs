﻿using Employee.Application.Dtos;
using Employee.Application.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JWT_RBACAuth.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _service;

        public EmployeeController(IEmployeeService service)
        {
            _service = service;
        }

        // GET: api/employee
        [HttpGet]
        [Authorize(Roles = "Admin,Manager,HR")]
        public async Task<IActionResult> GetAll()
        {
            var employees = await _service.GetAllAsync();
            return Ok(employees);
        }

        // GET: api/employee/5
        [HttpGet("{id}")]
        [Authorize(Roles = "Admin,Manager,HR")]
        public async Task<IActionResult> Get(int id)
        {
            var employee = await _service.GetByIdAsync(id);
            if (employee == null)
                return NotFound();

            return Ok(employee);
        }

        [HttpGet("profile")]
        [Authorize(Roles = "Employee")]
        public async Task<IActionResult> GetProfile()
        {
            var username = User.Identity!.Name!;
            var employee = await _service.GetByUsernameAsync(username);
            return Ok(employee);
        }

        // POST: api/employee
        [HttpPost]
        [Authorize(Roles = "Admin,Manager,HR")]
        public async Task<IActionResult> Create(EmployeeCreateDto dto)
        {
            await _service.CreateAsync(dto);
            return Ok("Employee created successfully");
        }

        // PUT: api/employee/5
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Manager,HR")]
        public async Task<IActionResult> Update(int id, EmployeeUpdateDto dto)
        {
            await _service.UpdateAsync(id, dto);
            return NoContent();
        }

        [HttpPut("profile")]
[Authorize(Roles = "Employee")]
public async Task<IActionResult> UpdateProfile(EmployeeUpdateDto dto)
{
    var username = User.Identity!.Name!;
    await _service.UpdateByUsernameAsync(username, dto);
    return NoContent();
}

        // DELETE: api/employee/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }
    }
}