# WorkNest — Angular Frontend for Employee Management

## Stack
- **Angular 17** (lazy-loaded feature modules)
- **Tailwind CSS** (via CDN in index.html)
- **JWT Authentication** (interceptor + guard)

## Project Structure

```
src/app/
├── core/
│   ├── guards/         auth.guard.ts
│   ├── interceptors/   jwt.interceptor.ts
│   └── services/       auth.service.ts  employee.service.ts  user.service.ts
├── features/
│   ├── auth/           Landing, Login, Register components + auth.module.ts
│   ├── admin/          AdminDashboard + admin.module.ts
│   ├── manager/        ManagerDashboard + manager.module.ts
│   └── employee/       EmployeeDashboard + employee.module.ts
├── shared/
│   ├── components/     navbar.component (reused across dashboards)
│   ├── models/         auth.models.ts  employee.models.ts
│   └── shared.module.ts
└── app-routing.module.ts (lazy routes)
```

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Set your API URL
Edit `src/environments/environment.ts`:
```ts
export const environment = {
  production: false,
  apiUrl: 'https://localhost:7001'  // ← your ASP.NET API URL
};
```

### 3. Configure CORS in ASP.NET
In your `Program.cs`, allow Angular's origin:
```csharp
builder.Services.AddCors(options => {
  options.AddDefaultPolicy(policy => {
    policy.WithOrigins("http://localhost:4200")
          .AllowAnyHeader()
          .AllowAnyMethod();
  });
});
// ...
app.UseCors();
```

### 4. Run
```bash
ng serve
```
Open `http://localhost:4200`

---

## Role-Based Flow

| Role     | Redirect     | Can Do                                          |
|----------|-------------|--------------------------------------------------|
| Admin    | /admin      | View/Create/Edit/Delete employees, Manage roles  |
| Manager  | /manager    | View/Create/Edit employees (no delete, no roles) |
| Employee | /employee   | View & Edit own profile only                     |

## Register Form Logic
- All roles available in dropdown: **Employee**, **Manager**, **Admin**
- When **Employee** or **Manager** is selected → Department & Salary fields appear
- Admin registration does not require Department/Salary

## Auth
- JWT token stored in `localStorage`
- `JwtInterceptor` automatically attaches `Authorization: Bearer <token>` to all requests
- `AuthGuard` protects routes and redirects unauthorized users
- Token expiry checked on each guard activation
