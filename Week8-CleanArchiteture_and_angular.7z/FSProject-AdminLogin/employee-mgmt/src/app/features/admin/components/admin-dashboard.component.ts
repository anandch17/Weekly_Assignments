import { Component, OnInit } from '@angular/core';
import { NavLink } from '../../../shared/components/navbar.component';
import { EmployeeService } from '../../../core/services/employee.service';
import { UserService } from '../../../core/services/user.service';
import { Employee, User } from '../../../shared/models/employee.models';
import { EmployeeCreateDto, EmployeeUpdateDto } from '../../../shared/models/employee.models';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
})
export class AdminDashboardComponent implements OnInit {
  navLinks: NavLink[] = [
    { label: 'Employees', route: '/admin' },
    { label: 'Users & Roles', route: '/admin/users' }];

  employees: Employee[] = [];
  users: User[] = [];
  activeTab = 'employees';
  loading = false;
  error = '';
  success = '';

  showCreateModal = false;
  showEditModal = false;
  editingEmployee: Employee | null = null;

  createForm: EmployeeCreateDto = { name: '', password: '', position: '', salary: 0 };
  editForm: EmployeeUpdateDto = {};

  availableRoles = ['Admin', 'HR', 'Employee'];

  constructor(private employeeService: EmployeeService, private userService: UserService) {}

  ngOnInit(): void {
    this.loadEmployees();
    this.loadUsers();
  }

  loadEmployees(): void {
    this.loading = true;
    this.employeeService.getAll().subscribe({
      next: (data) => { this.employees = data; this.loading = false; },
      error: () => { this.error = 'Failed to load employees'; this.loading = false; }
    });
  }

  loadUsers(): void {
    this.userService.getAll().subscribe({
      next: (data) => { this.users = data; },
      error: () => {}
    });
  }

createEmployee(): void {
  this.employeeService.create(this.createForm).subscribe({
    next: () => {
      this.success = 'Employee created successfully!';
      this.showCreateModal = false;        // ← this closes the modal
      this.createForm = { name: '', password: '', position: '', salary: 0 };
      this.loadEmployees();
      setTimeout(() => this.success = '', 3000);
    },
    error: (err) => { 
      this.error = err.error?.message || 'Failed to create employee'; 
    }
  });
}

  openEdit(emp: Employee): void {
    this.editingEmployee = emp;
    this.editForm = { position: emp.position, salary: emp.salary, name: emp.name };
    this.showEditModal = true;
  }

  updateEmployee(): void {
    if (!this.editingEmployee) return;
    this.employeeService.update(this.editingEmployee.id, this.editForm).subscribe({
      next: () => {
        this.success = 'Employee updated!';
        this.showEditModal = false;
        this.loadEmployees();
        setTimeout(() => this.success = '', 3000);
      },
      error: (err) => { this.error = err.error?.message || 'Update failed'; }
    });
  }

  deleteEmployee(id: number): void {
    if (!confirm('Are you sure you want to delete this employee?')) return;
    this.employeeService.delete(id).subscribe({
      next: () => { this.success = 'Employee deleted!'; this.loadEmployees(); setTimeout(() => this.success = '', 3000); },
      error: () => { this.error = 'Delete failed'; }
    });
  }

  setUserRole(userId: number, role: string): void {
    this.userService.setRole(userId, role).subscribe({
      next: () => { this.success = 'Role updated!'; this.loadUsers(); setTimeout(() => this.success = '', 3000); },
      error: () => { this.error = 'Failed to update role'; }
    });
  }
}
