import { Component, OnInit } from '@angular/core';
import { NavLink } from '../../../shared/components/navbar.component';
import { EmployeeService } from '../../../core/services/employee.service';
import { Employee, EmployeeCreateDto, EmployeeUpdateDto } from '../../../shared/models/employee.models';

@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager-dashboard.component.html',
})
export class ManagerDashboardComponent implements OnInit {
  navLinks: NavLink[] = [
    { label: 'Employees', route: '/manager' },
  ];

  employees: Employee[] = [];
  loading = false;
  error = '';
  success = '';

  showCreateModal = false;
  showEditModal = false;
  editingEmployee: Employee | null = null;

  createForm: EmployeeCreateDto = { name: '', password: '', position: '', salary: 0 };
  editForm: EmployeeUpdateDto = {};

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void { this.loadEmployees(); }

  loadEmployees(): void {
    this.loading = true;
    this.employeeService.getAll().subscribe({
      next: (data) => { this.employees = data; this.loading = false; },
      error: () => { this.error = 'Failed to load employees'; this.loading = false; }
    });
  }

  createEmployee(): void {
    this.employeeService.create(this.createForm).subscribe({
      next: () => {
        this.success = 'Employee created!';
        this.showCreateModal = false;
        this.createForm = { name: '', password: '', position: '', salary: 0 };
        this.loadEmployees();
        setTimeout(() => this.success = '', 3000);
      },
      error: (err) => { this.error = err.error?.message || 'Failed to create employee'; }
    });
  }

  openEdit(emp: Employee): void {
    this.editingEmployee = emp;
    this.editForm = { position: emp.position, salary: emp.salary, name: emp.name };
    this.showEditModal = true;
  }

  updateEmployee(): void {
    if (!this.editingEmployee) return;
    this.employeeService.update(this.editingEmployee.id, this.editForm).subscribe({
      next: () => {
        this.success = 'Employee updated!';
        this.showEditModal = false;
        this.loadEmployees();
        setTimeout(() => this.success = '', 3000);
      },
      error: () => { this.error = 'Update failed'; }
    });
  }
}
