import { Component, Input } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';

export interface NavLink {
  label: string;
  route: string;
  
}

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
})
export class NavbarComponent {
  @Input() navLinks: NavLink[] = [];
  mobileOpen = false;

  constructor(public authService: AuthService) {}

  get role(): string {
    return this.authService.getRole() || '';
  }

  get username(): string {
    return this.authService.getUsername() || '';
  }

  get roleBadgeClass(): string {
    switch (this.role) {
      case 'Admin': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'Manager': return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'Employee': return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      default: return 'bg-slate-500/20 text-slate-300 border-slate-500/30';
    }
  }

  logout(): void {
    this.authService.logout();
  }
}
