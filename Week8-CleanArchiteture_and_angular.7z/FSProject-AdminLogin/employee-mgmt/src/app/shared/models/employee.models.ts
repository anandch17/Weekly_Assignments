export interface Employee {
  id: number;
  name: string;
  position: string;
  salary: number;
  role?: string;
}

export interface EmployeeCreateDto {
  name: string;
  password: string;
  position: string;
  salary: number;
}

export interface EmployeeUpdateDto {
  position?: string;
  salary?: number;
  name?: string;
}

export interface User {
  id: number;
  name: string;
  role: string;
}
