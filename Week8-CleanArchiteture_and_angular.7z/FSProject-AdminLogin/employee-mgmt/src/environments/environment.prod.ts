export const environment = {
  production: true,
  apiUrl: 'https://your-api-url.com'
};
