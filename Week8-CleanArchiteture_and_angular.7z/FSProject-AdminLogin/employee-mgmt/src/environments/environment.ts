export const environment = {
  production: false,
  apiUrl: 'https://localhost:7264' // Change this to your ASP.NET API URL
};
