import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../Service/auth-service';
import { Employee } from '../../../Interface/Employee';
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view.html',
  styleUrl: './view.css',
})
export class View {

  users: Employee[] = [];

  constructor(private router: Router, private auth: AuthService,private cdr:ChangeDetectorRef) {}

  ngOnInit() {
    const token = localStorage.getItem('token');

    if (!token) {
      this.router.navigate(['/login']);
    } else {
      this.loadData();
    }
  }

  loadData() {
    this.auth.view().subscribe({
      next: (res: Employee[]) => {
          this.users = res; 
        this.cdr.detectChanges();  
      },
      error: (err) => console.log(err)
    });
  }
}
