import { Routes } from '@angular/router';
import { View } from './components/view/view';
import { Register } from './components/register/register';
import { Login } from './components/login/login';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
export const routes: Routes = [
    {path:'view',component:View},
    {path:'login',component:Login},
    {path:'register',component:Register}
];





