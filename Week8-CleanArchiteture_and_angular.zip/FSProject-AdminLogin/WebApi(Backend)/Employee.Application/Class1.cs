﻿namespace Employee.Application
{
    public class Class1
    {

    }
}
