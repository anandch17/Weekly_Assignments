﻿namespace Employee.Application.Dtos
{
    public record UserDto(
        int Id,
        string Username,
        string Role
    );
}