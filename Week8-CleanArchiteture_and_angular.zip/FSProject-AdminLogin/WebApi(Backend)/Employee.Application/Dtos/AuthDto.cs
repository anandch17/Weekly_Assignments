﻿namespace Employee.Application.Dtos
{
    public class AuthDto
    {
        public record RegisterDto(string Username,string Password,string Role,string? Department,decimal? Salary);
        public record LoginDto(string Username, string Password);
        public record AuthResultDto(string Token, string Username, string Role);


        public record ResetPasswordDto(string Username, string NewPassword);

    }
}
