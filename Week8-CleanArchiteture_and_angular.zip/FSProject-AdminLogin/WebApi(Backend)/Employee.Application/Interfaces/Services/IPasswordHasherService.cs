﻿using Employee.Domain.Entities;

public interface IPasswordHasherService
{
    string Hash(User user, string password);
    bool Verify(User user, string hash, string password);
}