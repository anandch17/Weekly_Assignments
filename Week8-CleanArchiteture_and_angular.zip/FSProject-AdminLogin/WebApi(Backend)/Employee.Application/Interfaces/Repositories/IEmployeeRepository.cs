﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntity = Employee.Domain.Entities.Employee;

namespace Employee.Application.Interfaces.Repositories
{
    public interface IEmployeeRepository
    {
        Task<List<EmployeeEntity>> GetAllAsync();
        Task<EmployeeEntity?> GetByIdAsync(int id);
        Task AddAsync(EmployeeEntity employee);
        Task UpdateAsync(EmployeeEntity employee);
        Task DeleteAsync(EmployeeEntity employee);

        Task SaveChangesAsync();
    }
}
