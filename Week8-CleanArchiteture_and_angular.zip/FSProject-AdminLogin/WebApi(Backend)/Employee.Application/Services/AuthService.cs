﻿using Employee.Application.Dtos;
using Employee.Application.Interfaces.Repositories;
using Employee.Application.Interfaces.Services;
using Employee.Domain.Entities;
using EmployeeEntity = Employee.Domain.Entities.Employee;

using Microsoft.AspNetCore.Identity;
using static Employee.Application.Dtos.AuthDto;

namespace Employee.Application.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _repo;
        private readonly PasswordHasher<User> _hasher;
        private readonly IJwtService _jwt;
        private readonly IEmployeeRepository _employeeRepo;

        public AuthService(IUserRepository repo, IJwtService jwt, IEmployeeRepository employeeRepo)
        {
            _repo = repo;
            _hasher = new PasswordHasher<User>();
            _jwt = jwt;
            _employeeRepo = employeeRepo;
        }

        public async Task<AuthResultDto> RegisterAsync(RegisterDto dto)
        {
            if (await _repo.ExistsAsync(dto.Username))
                throw new Exception("Username already exists");

            if (dto.Role != "Admin" && dto.Role != "HR" && dto.Role != "Employee")
                throw new Exception("Invalid role");

            var user = new User
            {
                Username = dto.Username,
                Role = dto.Role
            };

            user.PasswordHash = _hasher.HashPassword(user, dto.Password);

            await _repo.AddAsync(user);
            await _repo.SaveChangesAsync();   // generate User.Id

            // 🔥 Create Employee record only if HR or Employee
            if (dto.Role == "HR" || dto.Role == "Employee")
            {
                if (
                    string.IsNullOrWhiteSpace(dto.Department) ||
                    dto.Salary is null)
                {
                    throw new Exception("Employee details required");
                }

                var employee = new EmployeeEntity
                {
                    UserId = user.Id,
                    Name = dto.Username,
                    Position = dto.Department,
                    Salary = dto.Salary.Value
                };

                await _employeeRepo.AddAsync(employee);
                await _employeeRepo.SaveChangesAsync();
            }

            var token = _jwt.GenerateToken(user);

            return new AuthResultDto(token, user.Username, user.Role);
        }

        public async Task<AuthResultDto> LoginAsync(LoginDto dto)
        {
            var user = await _repo.GetByUsernameAsync(dto.Username)
                ?? throw new UnauthorizedAccessException("Invalid credentials");

            var result = _hasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password);
            if (result == PasswordVerificationResult.Failed)
                throw new UnauthorizedAccessException("Invalid credentials");

            var token = _jwt.GenerateToken(user);
            return new AuthResultDto(token, user.Username, user.Role);
        }
    }
}