﻿using Employee.Application.Dtos;
using Employee.Application.Interfaces.Repositories;
using Employee.Application.Interfaces.Services;
using Employee.Domain.Entities;

using Microsoft.AspNetCore.Identity;
using static Employee.Application.Dtos.AuthDto;

namespace Employee.Application.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _repo;
        private readonly PasswordHasher<User> _hasher;
        private readonly IJwtService _jwt;

        public AuthService(IUserRepository repo, IJwtService jwt)
        {
            _repo = repo;
            _hasher = new PasswordHasher<User>();
            _jwt = jwt;
        }

        public async Task<AuthResultDto> RegisterAsync(RegisterDto dto)
        {
            if (await _repo.ExistsAsync(dto.Username))
                throw new Exception("Username already exists");

            var user = new User
            {
                Username = dto.Username,
                Role = dto.Role ?? "User"
            };

            user.PasswordHash = _hasher.HashPassword(user, dto.Password);
            await _repo.AddAsync(user);
            await _repo.SaveChangesAsync();

            var token = _jwt.GenerateToken(user);
            return new AuthResultDto(token, user.Username, user.Role);
        }

        public async Task<AuthResultDto> LoginAsync(LoginDto dto)
        {
            var user = await _repo.GetByUsernameAsync(dto.Username)
                ?? throw new Exception("Invalid credentials");

            var result = _hasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password);
            if (result == PasswordVerificationResult.Failed)
                throw new Exception("Invalid credentials");

            var token = _jwt.GenerateToken(user);
            return new AuthResultDto(token, user.Username, user.Role);
        }
    }
}