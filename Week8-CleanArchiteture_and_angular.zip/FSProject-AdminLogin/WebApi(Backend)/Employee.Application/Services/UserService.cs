﻿using Employee.Application.Dtos;
using Employee.Application.Interfaces.Repositories;
using Employee.Application.Interfaces.Services;

namespace Employee.Application.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _repo;

        public UserService(IUserRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<UserDto>> GetAllAsync()
        {
            var users = await _repo.GetAllAsync();

            return users.Select(u =>
                new UserDto(u.Id, u.Username, u.Role));
        }

        public async Task<UserDto?> GetByIdAsync(int id)
        {
            var user = await _repo.GetByIdAsync(id);
            if (user == null) return null;

            return new UserDto(user.Id, user.Username, user.Role);
        }

        public async Task SetRoleAsync(int id, string role)
        {
            var user = await _repo.GetByIdAsync(id)
                ?? throw new Exception("User not found");

            user.Role = role;
            await _repo.SaveChangesAsync();
        }
    }
}