﻿using Employee.Application.Dtos;
using Employee.Application.Interfaces.Repositories;
using Employee.Application.Interfaces.Services;
using Employee.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using EmployeeEntity = Employee.Domain.Entities.Employee;

namespace Employee.Application.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _repo;
        private readonly IUserRepository _userRepo;
        private readonly IPasswordHasherService _hasher;

        public EmployeeService(IEmployeeRepository repo, IUserRepository userRepo, IPasswordHasherService hasher)
        {
            _repo = repo;
            _userRepo = userRepo;
            _hasher = hasher;
        }

        public async Task<IEnumerable<EmployeeDto>> GetAllAsync()
        {
            var employees = await _repo.GetAllAsync();

            return employees.Select(e =>
                new EmployeeDto(e.Id, e.Name, e.Position, e.Salary));
        }


        public async Task UpdateByUsernameAsync(string username, EmployeeUpdateDto dto)
        {
            var employee = await _repo.GetByUsernameAsync(username);

            if (employee == null)
                throw new Exception("Employee not found");

            employee.Position = dto.Position;
            employee.Salary = dto.Salary;

            await _repo.SaveChangesAsync();
        }

        public async Task<EmployeeDto?> GetByUsernameAsync(string username)
        {
            var e = await _repo.GetByUsernameAsync(username);
            if (e == null) return null;
            return new EmployeeDto(e.Id, e.Name, e.Position, e.Salary);
        }

        public async Task<EmployeeDto?> GetByIdAsync(int id)
        {
            var e = await _repo.GetByIdAsync(id);
            if (e == null) return null;

            return new EmployeeDto(e.Id, e.Name, e.Position, e.Salary);
        }

      

        public async Task CreateAsync(EmployeeCreateDto dto)
        {
            // First create a User
            var user = new User
            {
                Username = dto.Name,
                Role = "Employee"
            };
            user.PasswordHash = _hasher.Hash(user, dto.Password);
            await _userRepo.AddAsync(user);
            await _userRepo.SaveChangesAsync(); // generates user.Id

            // Then create Employee with valid UserId
            var employee = new EmployeeEntity
            {
                Name = dto.Name,
                Position = dto.Position,
                Salary = dto.Salary,
                UserId = user.Id  // ← now valid
            };
            await _repo.AddAsync(employee);
            await _repo.SaveChangesAsync();
        }

        public async Task UpdateAsync(int id, EmployeeUpdateDto dto)
        {
            var e = await _repo.GetByIdAsync(id)
                ?? throw new Exception("Employee not found");

            e.Name = dto.Name;
            e.Position = dto.Position;
            e.Salary = dto.Salary;

            await _repo.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var e = await _repo.GetByIdAsync(id)
                ?? throw new Exception("Employee not found");

            await _repo.DeleteAsync(e);
            await _repo.SaveChangesAsync();
        }
    }
}