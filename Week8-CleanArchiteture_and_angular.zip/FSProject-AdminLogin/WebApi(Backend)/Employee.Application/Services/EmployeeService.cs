﻿using Employee.Application.Dtos;
using Employee.Application.Interfaces.Repositories;
using Employee.Application.Interfaces.Services;
using Employee.Domain.Entities;
using EmployeeEntity = Employee.Domain.Entities.Employee;

namespace Employee.Application.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _repo;

        public EmployeeService(IEmployeeRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<EmployeeDto>> GetAllAsync()
        {
            var employees = await _repo.GetAllAsync();

            return employees.Select(e =>
                new EmployeeDto(e.Id, e.Name, e.Position, e.Salary));
        }

        public async Task<EmployeeDto?> GetByIdAsync(int id)
        {
            var e = await _repo.GetByIdAsync(id);
            if (e == null) return null;

            return new EmployeeDto(e.Id, e.Name, e.Position, e.Salary);
        }

        public async Task CreateAsync(EmployeeCreateDto dto)
        {
            var employee = new EmployeeEntity
            {
                Name = dto.Name,
                Position = dto.Position,
                Salary = dto.Salary
            };

            await _repo.AddAsync(employee);
            await _repo.SaveChangesAsync();
        }

        public async Task UpdateAsync(int id, EmployeeUpdateDto dto)
        {
            var e = await _repo.GetByIdAsync(id)
                ?? throw new Exception("Employee not found");

            e.Name = dto.Name;
            e.Position = dto.Position;
            e.Salary = dto.Salary;

            await _repo.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var e = await _repo.GetByIdAsync(id)
                ?? throw new Exception("Employee not found");

            await _repo.DeleteAsync(e);
            await _repo.SaveChangesAsync();
        }
    }
}