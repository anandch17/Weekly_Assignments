﻿namespace Employee.Infrastructure
{
    public class Class1
    {

    }
}
