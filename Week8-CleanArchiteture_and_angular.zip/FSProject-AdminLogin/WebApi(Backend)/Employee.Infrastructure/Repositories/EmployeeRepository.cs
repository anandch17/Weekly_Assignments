﻿using Employee.Application.Interfaces.Repositories;
using Employee.Domain.Entities;
using Employee.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using EmployeeEntity = Employee.Domain.Entities.Employee;

namespace Employee.Infrastructure.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly AppDbContext _db;

        public EmployeeRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<List<EmployeeEntity>> GetAllAsync()
            => await _db.Employees.ToListAsync();

        public async Task<EmployeeEntity?> GetByIdAsync(int id)
            => await _db.Employees.FindAsync(id);

        public async Task AddAsync(EmployeeEntity employee)
            => await _db.Employees.AddAsync(employee);

        public async Task DeleteAsync(EmployeeEntity employee)
            => _db.Employees.Remove(employee);

        public async Task UpdateAsync(EmployeeEntity employee)
        
            => _db.Employees.Update(employee);
             
        

        public async Task SaveChangesAsync()
            => await _db.SaveChangesAsync();
    }
}