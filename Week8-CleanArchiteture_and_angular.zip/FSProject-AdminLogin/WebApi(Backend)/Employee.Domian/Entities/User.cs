﻿using System.ComponentModel.DataAnnotations;

namespace  Employee.Domain.Entities
{
    public class User
    {
        public int Id { get; set; }

        public string Username { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public string Role { get; set; } = null!;

        public string? Email { get; set; }
        public string? ResetToken { get; set; }
        public DateTime? ResetTokenExpiry { get; set; }

        // Navigation property (1-to-1)
        public Employee? Employee { get; set; }

    }
}
