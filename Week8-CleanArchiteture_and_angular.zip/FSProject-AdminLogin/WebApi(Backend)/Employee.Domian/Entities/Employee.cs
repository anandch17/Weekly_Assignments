﻿using System.ComponentModel.DataAnnotations;

namespace Employee.Domain.Entities
{
    public class Employee
    {
        public int Id { get; set; }

        [Required]


        public int UserId { get; set; }   // Foreign Key
        public string Name { get; set; } = null!;
        public string? Position { get; set; }
        public decimal Salary { get; set; }

        public User User { get; set; } = null!;
    }
}
