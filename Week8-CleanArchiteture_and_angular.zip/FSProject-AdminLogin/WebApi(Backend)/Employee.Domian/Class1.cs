﻿namespace Employee.Domian
{
    public class Class1
    {

    }
}
