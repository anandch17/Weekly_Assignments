export interface RegisterDto {
  username: string;
  password: string;
  role: string;
  department?: string;
  salary?: number;
}

export interface LoginDto {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  role: string;
  username: string;
}

export interface DecodedToken {
  unique_name: string;
  role: string;
  exp: number;
}
