import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { AuthResponse, LoginDto, RegisterDto, DecodedToken } from '../../shared/models/auth.models';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = `${environment.apiUrl}/api/auth`;

  constructor(private http: HttpClient, private router: Router) {}

  register(dto: RegisterDto): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, dto);
  }

  login(dto: LoginDto): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, dto).pipe(
      tap(res => {
        localStorage.setItem('token', res.token);
        localStorage.setItem('role', res.role);
        localStorage.setItem('username', res.username);
      })
    );
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/']);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getRole(): string | null {
    return localStorage.getItem('role');
  }

  getUsername(): string | null {
    return localStorage.getItem('username');
  }

  isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) return false;
    try {
      const decoded = this.decodeToken(token);
      return decoded.exp * 1000 > Date.now();
    } catch {
      return false;
    }
  }

  decodeToken(token: string): DecodedToken {
    const payload = token.split('.')[1];
    return JSON.parse(atob(payload));
  }

  redirectToDashboard(): void {
    const role = this.getRole();
    console.log('Role from localStorage:', role);
    switch (role) {
      case 'Admin': this.router.navigate(['/admin']); break;
      case 'HR': this.router.navigate(['/hr']); break;
      case 'Employee': this.router.navigate(['/employee']); break;
      default: this.router.navigate(['/']);
    }
  }



resetPassword(username: string, newPassword: string): Observable<any> {
  return this.http.post(
    `${this.apiUrl}/reset-password`, 
    { username, newPassword },
    { responseType: 'text' }
  );
}
}
