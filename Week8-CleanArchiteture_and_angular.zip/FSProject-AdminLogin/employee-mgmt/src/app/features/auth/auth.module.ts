import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from './components/landing.component';
import { LoginComponent } from './components/login.component';
import { RegisterComponent } from './components/register.component';
import { ResetPasswordComponent } from './components/reset-password.component';
import { FormsModule } from '@angular/forms';

const routes: Routes = [
  { path: '', component: LandingComponent },
    { path: 'reset-password', component: ResetPasswordComponent }
];

@NgModule({
  declarations: [LandingComponent, LoginComponent, RegisterComponent, ResetPasswordComponent],
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    FormsModule,        // ← add this
    RouterModule.forChild(routes)
  ]
})
export class AuthModule {}
