import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-reset-password',
  template: `
    <div class="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div class="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-sm p-6 space-y-4">
        <h2 class="text-xl font-bold text-white">Set New Password</h2>

        <div *ngIf="success" class="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3 text-emerald-400 text-sm">{{ success }}</div>
        <div *ngIf="error" class="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-red-400 text-sm">{{ error }}</div>

        <div>
          <label class="block text-slate-300 text-sm font-medium mb-1.5">New Password</label>
          <input [(ngModel)]="newPassword" type="password"
            class="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-indigo-500" />
        </div>
        <div>
          <label class="block text-slate-300 text-sm font-medium mb-1.5">Confirm Password</label>
          <input [(ngModel)]="confirmPassword" type="password"
            class="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-indigo-500" />
        </div>

        <button (click)="submit()" [disabled]="loading"
          class="w-full py-2.5 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-sm font-semibold disabled:opacity-50">
          {{ loading ? 'Resetting...' : 'Reset Password' }}
        </button>
      </div>
    </div>
  `
})
export class ResetPasswordComponent implements OnInit {
  token = '';
  newPassword = '';
  confirmPassword = '';
  loading = false;
  success = '';
  error = '';

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.token = this.route.snapshot.queryParams['token'];
    if (!this.token) this.router.navigate(['/']);
  }

  submit(): void {
    if (this.newPassword !== this.confirmPassword) {
      this.error = 'Passwords do not match';
      return;
    }
    this.loading = true;
    this.authService.resetPassword(this.token, this.newPassword).subscribe({
      next: () => {
        this.success = 'Password reset! Redirecting to login...';
        setTimeout(() => this.router.navigate(['/']), 2000);
      },
      error: (err) => {
        this.loading = false;
        this.error = err.error?.message || 'Reset failed';
      }
    });
  }
}