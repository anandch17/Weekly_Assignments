import { Component, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
})
export class RegisterComponent {
  @Output() switchToLogin = new EventEmitter<void>();

  form: FormGroup;
  loading = false;
  error = '';
  success = '';
  showPassword = false;

  roles = ['Employee', 'HR', 'Admin'];

  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['', Validators.required],
      department: [''],
      salary: [null],
    });

    this.form.get('role')!.valueChanges.subscribe(role => {
      const dept = this.form.get('department')!;
      const sal = this.form.get('salary')!;
      if (role === 'Employee' || role === 'HR') {
        dept.setValidators(Validators.required);
        sal.setValidators([Validators.required, Validators.min(0)]);
      } else {
        dept.clearValidators();
        sal.clearValidators();
        dept.setValue('');
        sal.setValue(null);
      }
      dept.updateValueAndValidity();
      sal.updateValueAndValidity();
    });
  }

  get showExtraFields(): boolean {
    const role = this.form.get('role')?.value;
    return role === 'Employee' || role === 'HR';
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';
    this.success = '';

    const dto: any = {
      username: this.form.value.username,
      password: this.form.value.password,
      role: this.form.value.role,
    };
    if (this.showExtraFields) {
      dto.department = this.form.value.department;
      dto.salary = this.form.value.salary;
    }

    this.authService.register(dto).subscribe({
      next: () => {
        this.loading = false;
        this.success = 'Registration successful! You can now sign in.';
        this.form.reset();
        setTimeout(() => this.switchToLogin.emit(), 1500);
      },
      error: (err) => {
        this.loading = false;
        this.error = err.error?.message || 'Registration failed. Please try again.';
      }
    });
  }
}
