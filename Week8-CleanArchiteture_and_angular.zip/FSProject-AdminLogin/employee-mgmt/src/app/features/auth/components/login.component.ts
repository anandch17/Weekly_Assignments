import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';

declare var grecaptcha: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  loading = false;
  error = '';
  showPassword = false;
  captchaVerified = false;

  // forgot password
  showForgotPassword = false;
  forgotUsername = '';
  forgotNewPassword = '';
  forgotConfirmPassword = '';
  forgotLoading = false;
  forgotError = '';
  forgotSuccess = '';

  constructor(private fb: FormBuilder, private authService: AuthService) {
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

ngOnInit(): void {
  (window as any).onCaptchaSuccess = () => {
    this.captchaVerified = true;
  };
  (window as any).onCaptchaExpired = () => {
    this.captchaVerified = false;
  };

  // wait for grecaptcha to be ready then render
  const waitForCaptcha = setInterval(() => {
    if ((window as any).grecaptcha && document.getElementById('captcha-container')) {
      clearInterval(waitForCaptcha);
      (window as any).grecaptcha.render('captcha-container', {
        sitekey: '6Lca4nUsAAAAAM2r4nNa0DSomAdmITYRcUixpZjl',
        theme: 'dark',
        callback: 'onCaptchaSuccess',
        'expired-callback': 'onCaptchaExpired'
      });
    }
  }, 200);
}

  submit(): void {
    if (this.form.invalid || !this.captchaVerified) return;
    this.loading = true;
    this.error = '';
    this.authService.login(this.form.value).subscribe({
      next: () => {
        this.loading = false;
        this.authService.redirectToDashboard();
      },
      error: (err) => {
        this.loading = false;
        this.error = err.error?.message || 'Invalid credentials.';
        grecaptcha.reset();
        this.captchaVerified = false;
      }
    });
  }

  submitResetPassword(): void {
    this.forgotError = '';
    this.forgotSuccess = '';

    if (!this.forgotUsername || !this.forgotNewPassword) {
      this.forgotError = 'Please fill all fields';
      return;
    }
    if (this.forgotNewPassword !== this.forgotConfirmPassword) {
      this.forgotError = 'Passwords do not match';
      return;
    }

    this.forgotLoading = true;
    this.authService.resetPassword(this.forgotUsername, this.forgotNewPassword).subscribe({
      next: () => {
        this.forgotLoading = false;
        this.forgotSuccess = 'Password reset successfully!';
        setTimeout(() => {
          this.showForgotPassword = false;
          this.forgotUsername = '';
          this.forgotNewPassword = '';
          this.forgotConfirmPassword = '';
          this.forgotSuccess = '';
        }, 2000);
      },
      error: (err) => {
        this.forgotLoading = false;
        this.forgotError = err.error?.message || 'Reset failed';
      }
    });
  }
}