import { Component, OnInit } from '@angular/core';
import { NavLink } from '../../../shared/components/navbar.component';
import { EmployeeService } from '../../../core/services/employee.service';
import { Employee, EmployeeUpdateDto } from '../../../shared/models/employee.models';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
})
export class EmployeeDashboardComponent implements OnInit {
  navLinks: NavLink[] = [
    { label: 'My Profile', route: '/employee'},
  ];

  profile: Employee | null = null;
  loading = false;
  error = '';
  success = '';
  editing = false;

  editForm: EmployeeUpdateDto = {};

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void { this.loadProfile(); }

  loadProfile(): void {
    this.loading = true;
    this.employeeService.getProfile().subscribe({
      next: (data) => { this.profile = data; this.loading = false; },
      error: () => { this.error = 'Failed to load profile'; this.loading = false; }
    });
  }

  startEdit(): void {
  this.editForm = { 
    position: this.profile?.position,  
    salary: this.profile?.salary, 
    name: this.profile?.name 
  };
  this.editing = true;
}

  saveProfile(): void {
    this.employeeService.updateProfile(this.editForm).subscribe({
      next: () => {
        this.success = 'Profile updated successfully!';
        this.editing = false;
        this.loadProfile();
        setTimeout(() => this.success = '', 3000);
      },
      error: () => { this.error = 'Failed to update profile'; }
    });
  }
}
