using AuthService.Domain;

namespace AuthService.Application.Common.Interfaces
{
    public interface IJwtGenerator
    {
        string GenerateToken(User user);
    }
}
