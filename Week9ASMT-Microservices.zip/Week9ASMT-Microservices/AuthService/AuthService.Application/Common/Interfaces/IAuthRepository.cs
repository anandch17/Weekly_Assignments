using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Domain;

namespace AuthService.Application.Common.Interfaces
{
    public interface IAuthRepository
    {
        Task<User?> GetByIdAsync(Guid id);
        Task<User?> GetByEmailAsync(string email);
        Task<IEnumerable<User>> GetAllAsync();
        Task AddAsync(User user);
    }
}
