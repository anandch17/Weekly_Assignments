using System;

namespace AuthService.Application.DTOs
{
    public record UserDto(Guid Id, string Email, string Role, DateTime CreatedAt);
    public record LoginRequest(string Email, string Password);
    public record RegisterRequest(string Email, string Password, string Role);
    public record AuthResponse(UserDto User, string Token);
}
