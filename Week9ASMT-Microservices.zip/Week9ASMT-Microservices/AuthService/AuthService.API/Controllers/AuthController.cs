using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthService.Application.Common.Interfaces;
using AuthService.Application.DTOs;
using AuthService.Domain;
using Microsoft.AspNetCore.Mvc;

namespace AuthService.API.Controllers
{
    [ApiController]
    [Route("auth")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _repository;
        private readonly IJwtGenerator _jwtGenerator;

        public AuthController(IAuthRepository repository, IJwtGenerator jwtGenerator)
        {
            _repository = repository;
            _jwtGenerator = jwtGenerator;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            var existingUser = await _repository.GetByEmailAsync(request.Email);
            if (existingUser != null) return BadRequest("User already exists");

            var user = new User
            {
                Id = Guid.NewGuid(),
                Email = request.Email,
                // In a real app, use BCrypt or similar to hash the password
                PasswordHash = request.Password, 
                Role = request.Role,
                CreatedAt = DateTime.UtcNow
            };

            await _repository.AddAsync(user);

            var token = _jwtGenerator.GenerateToken(user);
            return Ok(new AuthResponse(new UserDto(user.Id, user.Email, user.Role, user.CreatedAt), token));
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            var user = await _repository.GetByEmailAsync(request.Email);
            if (user == null || user.PasswordHash != request.Password) 
                return Unauthorized("Invalid credentials");

            var token = _jwtGenerator.GenerateToken(user);
            return Ok(new AuthResponse(new UserDto(user.Id, user.Email, user.Role, user.CreatedAt), token));
        }

        [HttpGet("users")]
        public async Task<IActionResult> GetUsers()
        {
            var users = await _repository.GetAllAsync();
            var dtos = users.Select(u => new UserDto(u.Id, u.Email, u.Role, u.CreatedAt));
            return Ok(dtos);
        }

        [HttpGet("users/{id}")]
        public async Task<IActionResult> GetUser(Guid id)
        {
            var user = await _repository.GetByIdAsync(id);
            if (user == null) return NotFound();
            return Ok(new UserDto(user.Id, user.Email, user.Role, user.CreatedAt));
        }
    }
}
