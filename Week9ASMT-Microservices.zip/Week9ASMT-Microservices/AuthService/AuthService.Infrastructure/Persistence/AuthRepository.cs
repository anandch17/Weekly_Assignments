using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AuthService.Application.Common.Interfaces;
using AuthService.Domain;
using MongoDB.Driver;
using Microsoft.Extensions.Configuration;

namespace AuthService.Infrastructure.Persistence
{
    public class AuthRepository : IAuthRepository
    {
        private readonly IMongoCollection<User> _users;

        public AuthRepository(IConfiguration configuration)
        {
            var client = new MongoClient(configuration.GetConnectionString("MongoDb"));
            var database = client.GetDatabase("AuthDb");
            _users = database.GetCollection<User>("Users");
        }

        public async Task<User?> GetByIdAsync(Guid id) =>
            await _users.Find(u => u.Id == id).FirstOrDefaultAsync();

        public async Task<User?> GetByEmailAsync(string email) =>
            await _users.Find(u => u.Email == email).FirstOrDefaultAsync();

        public async Task<IEnumerable<User>> GetAllAsync() =>
            await _users.Find(_ => true).ToListAsync();

        public async Task AddAsync(User user) =>
            await _users.InsertOneAsync(user);
    }
}
