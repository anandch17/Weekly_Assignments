using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NotificationService.Domain;

namespace NotificationService.Application.Common.Interfaces
{
    public interface INotificationRepository
    {
        Task<IEnumerable<Notification>> GetByEmailAsync(string email);
        Task AddAsync(Notification notification);
    }
}
