using System;

namespace NotificationService.Application.DTOs
{
    public record CreateNotificationRequest(string UserEmail, string Message);
}
