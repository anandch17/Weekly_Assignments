using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NotificationService.Application.Common.Interfaces;
using NotificationService.Application.DTOs;
using NotificationService.Domain;

namespace NotificationService.API.Controllers
{
    [ApiController]
    [Route("notifications")]
    public class NotificationsController : ControllerBase
    {
        private readonly INotificationRepository _repository;

        public NotificationsController(INotificationRepository repository)
        {
            _repository = repository;
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateNotificationRequest request)
        {
            var notification = new Notification
            {
                Id = Guid.NewGuid(),
                UserEmail = request.UserEmail,
                Message = request.Message,
                CreatedAt = DateTime.UtcNow
            };

            await _repository.AddAsync(notification);
            return Ok(notification);
        }

        [HttpGet("{userEmail}")]
        public async Task<IActionResult> GetByUser(string userEmail)
        {
            var notifications = await _repository.GetByEmailAsync(userEmail);
            return Ok(notifications);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            // For simplicity, returning all from repository if needed, or just a sample
            return Ok(await _repository.GetByEmailAsync(string.Empty)); 
        }
    }
}
