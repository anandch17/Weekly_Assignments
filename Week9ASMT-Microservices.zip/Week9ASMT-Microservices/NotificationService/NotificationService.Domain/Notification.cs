using System;

namespace NotificationService.Domain
{
    public class Notification
    {
        public Guid Id { get; set; }
        public string UserEmail { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
