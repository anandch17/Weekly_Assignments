using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskService.Application.Common.Interfaces;
using TaskService.Application.DTOs;
using TaskService.Domain;

namespace TaskService.API.Controllers
{
    [ApiController]
    [Route("tasks")]
    
    public class TasksController : ControllerBase
    {
        private readonly ITaskRepository _repository;
        private readonly HttpClient _httpClient;

        public TasksController(ITaskRepository repository, IHttpClientFactory httpClientFactory)
        {
            _repository = repository;
            _httpClient = httpClientFactory.CreateClient();
        }

        [HttpPost]
        [Authorize(Roles = "Manager,TeamLead")]
        public async Task<IActionResult> Create(CreateTaskRequest request)
        {
            var task = new TaskEntity
            {
                Id = Guid.NewGuid(),
                Title = request.Title,
                Description = request.Description,
                AssignedTo = request.AssignedTo,
                Deadline = request.Deadline,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            await _repository.AddAsync(task);

            // Call NotificationService
            try
            {
                var notification = new { UserEmail = task.AssignedTo, Message = $"New task assigned: {task.Title}" };
                await _httpClient.PostAsJsonAsync("http://localhost:5003/notifications", notification);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to send notification: {ex.Message}");
            }

            return CreatedAtAction(nameof(GetById), new { id = task.Id }, task);
        }

        [HttpGet]
        [Authorize(Roles = "Manager,TeamLead")]
        public async Task<IActionResult> GetAll()
        {
            var tasks = await _repository.GetAllAsync();
            return Ok(tasks);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var task = await _repository.GetByIdAsync(id);
            if (task == null) return NotFound();
            return Ok(task);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, UpdateTaskRequest request)
        {
            var task = await _repository.GetByIdAsync(id);
            if (task == null) return NotFound();

            task.Title = request.Title;
            task.Description = request.Description;
            task.AssignedTo = request.AssignedTo;
            task.Deadline = request.Deadline;
            task.Status = request.Status;

            await _repository.UpdateAsync(task);
            return NoContent();
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Manager,TeamLead")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }
    }
}
