using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TaskService.Domain;

namespace TaskService.Application.Common.Interfaces
{
    public interface ITaskRepository
    {
        Task<TaskEntity?> GetByIdAsync(Guid id);
        Task<IEnumerable<TaskEntity>> GetAllAsync();
        Task AddAsync(TaskEntity task);
        Task UpdateAsync(TaskEntity task);
        Task DeleteAsync(Guid id);
    }
}
