using System;

namespace TaskService.Application.DTOs
{
    public record TaskDto(Guid Id, string Title, string Description, string AssignedTo, DateTime Deadline, string Status, DateTime CreatedAt);
    public record CreateTaskRequest(string Title, string Description, string AssignedTo, DateTime Deadline);
    public record UpdateTaskRequest(string Title, string Description, string AssignedTo, DateTime Deadline, string Status);
}
